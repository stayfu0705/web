from flask import render_template, session, redirect, url_for, current_app, request, flash, Flask,render_template_string , abort,send_from_directory,Response
from . import main
from ..models import db
from config import URI
from sqlalchemy_utils import database_exists, create_database
import os, sys, time
from hdfs import InsecureClient
from confluent_kafka import Producer


client = InsecureClient('http://10.120.14.120:50070', user='cloudera')

UPLOAD_PATH = 'static/uploads/'
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT1 = os.path.abspath(os.path.dirname(APP_ROOT))
UPLOAD_FOLDER = os.path.join(APP_ROOT1, UPLOAD_PATH)

UPLOAD_PATH1 = 'static/predict/'
UPLOAD_FOLDER1 = os.path.join(APP_ROOT1, UPLOAD_PATH1)

@main.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@main.route('/createdb/', methods=['GET', 'POST'])
def createdb():
    if not database_exists(URI):
        create_database(URI)
    print("資料庫已經存在")
    db.create_all()
    return redirect(url_for("main.index"))

@main.route('/dashboard_CT/')
def dashboard_CT():
    return render_template("dashboard_CT.html")

@main.route('/dashboard_MRI/')
def dashboard_MRI():
    return render_template("dashboard_MRI.html")

@main.route('/google_calendar/', methods=['GET', 'POST'])
def google_calendar():
    return render_template("google_calendar.html")

@main.route('/about_us/')
def about_us():
    return render_template("about_us.html")


@main.route('/images_predict', methods=['GET', 'POST'])
def images_prefdict():

    all_image_files = []
    for filename in os.listdir(UPLOAD_FOLDER):
        ## 圖片檔

        #filename = filename[len(filename):]
        if (isImageFormat(filename)):
            all_image_files.append(filename)


    all_image_files2 = []
    for filename in os.listdir(UPLOAD_FOLDER1):
        ## 圖片檔

        #filename = filename[len(filename):]
        if (isImageFormat(filename)):
            all_image_files2.append(filename)

    return render_template('images_predict.html',**locals())



# 符合圖片檔案
def isImageFormat(link):
    if (link.find('.jpg') > -1 or link.find('.png') > -1 or link.find('.gif') > -1 or link.find('.jpeg') > -1):
        return True
    return False


@main.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        print(file)
        upload_path = '{}/{}'.format(UPLOAD_FOLDER, file.filename)
        # save file to local file path
        file.save(upload_path)
        # upload to hdfs
        # client.upload("/user/cloudera/test/uploads", upload_path)

        # produce to kafka
        props = {
            # Kafka集群在那裡?
            'bootstrap.servers': '10.120.14.120:9092',  # <-- 置換成要連接的Kafka集群
            'max.in.flight.requests.per.connection': 1,
            'error_cb': error_cb  # 設定接收error訊息的callback函數
        }
        # 步驟2. 產生一個Kafka的Producer的實例
        #
        producer = Producer(**props)

        # 步驟3. 指定想要發佈訊息的topic名稱
        topicName = 'CTimgt'
        try:
            print('Start sending messages ...')
            # produce(topic, [value], [key], [partition], [on_delivery], [timestamp], [headers])
            with open(upload_path, 'rb') as r:
                data = r.read()
            producer.produce(topicName, key=str(file.filename), value=data)
            producer.poll(0)  # <-- (重要) 呼叫poll來讓client程式去檢查內部的Buffer
            print('key ={}, value ={}'.format(str(file.filename), 'img_' + str(data)))
            time.sleep(3)  # 讓主執行緒停個3秒

            print('Send ' + ' img' + ' binary messages to Kafka')
        except BufferError as e:
            # 錯誤處理
            sys.stderr.write('%% Local producer queue is full ({} messages awaiting delivery): try again\n'
                             .format(len(producer)))
        except Exception as e:
            print(e)
        # 步驟5. 確認所有在Buffer裡的訊息都己經送出去給Kafka了
        producer.flush(10)
        print('Message sending completed!')
        return 'ok'

def error_cb(err):
    print('Error: %s' % err)
