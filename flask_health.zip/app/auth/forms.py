
from flask_wtf import Form
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length, Email, Regexp, EqualTo
from wtforms import ValidationError
from ..models import User,Patient
import etl


class LoginForm(Form):
    email = StringField(u'電子郵件',
                        validators=[DataRequired(message=u'請輸入電子郵件'), Length(1, 64, u'電子郵件超過長度'), Email(u'電子郵件不符合規範')])
    password = PasswordField(u'密碼', validators=[DataRequired(u'請輸入密碼')])
    remember_me = BooleanField(u'保持登入')
    submit = SubmitField(u'登入')


class RegistrationForm(Form):
    email = StringField(u'電子郵件', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64), Email(u'電子郵件不符合規範')])
    username = StringField(u'使用者名稱', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64),
                                                 Regexp('^[A-Za-z][A-Za-z0-9_.]*$', 0, u'使用者名稱只允許使用英文.數字.小數點或者下底線')])
    password = PasswordField(u'密碼',
                             validators=[DataRequired(message=u'此欄位不得為空'), EqualTo('password2', message=u'密碼兩次必須輸入相同')])
    password2 = PasswordField(u'確認密碼', validators=[DataRequired(message=u'此欄位不得為空')])
    submit = SubmitField(u'註冊')

    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError(u'電子郵件已註冊過')


class PatientForms(Form):
    PNO = StringField(u'病歷號碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])
    ITEM = StringField(u'檢查代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)]) #,Regexp('^[A-Za-z][A-Za-z0-9_.]*$', 0, u'使用者名稱只允許使用英文.數字.小數點或者下底線')])
    ORDERDR = StringField(u'醫生代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])
    PLACE = StringField(u'檢查地點代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])
    IO = StringField(u'門診急診住院代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])
    DEPT = StringField(u'科別代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])
    SEX = StringField(u'性別代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])
    AGE = StringField(u'年齡', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])
    POS = StringField(u'部位代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])

    # AMOUNT = StringField(u'檢查代碼', validators=[DataRequired(message=u'此欄位不得為空'), Length(1, 64)])

    # password = PasswordField(u'密碼',
    #                          validators=[DataRequired(message=u'此欄位不得為空'), EqualTo('password2', message=u'密碼兩次必須輸入相同')])
    # password2 = PasswordField(u'確認密碼', validators=[DataRequired(message=u'此欄位不得為空')])
    submit = SubmitField(u'送出')
    #


    def validate_PNO(self, field):
        if Patient.query.filter_by(PNO=field.data).first():
            raise ValidationError(u'病歷號已註冊過')
    def validate_ITEM(self, field):
        if field.data not in etl.ITEM:
            raise ValidationError(u'輸入資料錯誤，請再次確認輸入資料!')
    def validate_ORDERDR(self, field):
        if field.data not in etl.ORDERDR:
            raise ValidationError(u'輸入資料錯誤，請再次確認輸入資料!')
    def validate_PLACE(self, field):
        if field.data not in etl.PLACE:
            raise ValidationError(u'輸入資料錯誤，請再次確認輸入資料!')
    def validate_IO(self, field):
        if field.data not in etl.IO:
            raise ValidationError(u'輸入資料錯誤，請再次確認輸入資料!')
    def validate_DEPT(self, field):
        if field.data not in etl.DEPT:
            raise ValidationError(u'輸入資料錯誤，請再次確認輸入資料!')
    def validate_SEX(self, field):
        if field.data not in etl.SEX:
            raise ValidationError(u'輸入資料錯誤，請再次確認輸入資料!')
    def validate_POS(self, field):
        if field.data not in etl.POS:
            raise ValidationError(u'輸入資料錯誤，請再次確認輸入資料!')