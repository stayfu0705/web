from flask import render_template, session, redirect, url_for, current_app, request, flash, Flask,render_template_string , abort,send_from_directory,Response
from . import main
from ..models import db
from config import URI
from sqlalchemy_utils import database_exists, create_database
import os
from hdfs import InsecureClient



client = InsecureClient('http://10.120.14.120:50070', user='cloudera')

UPLOAD_PATH = 'static/uploads'
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT1 = os.path.abspath(os.path.dirname(APP_ROOT))
UPLOAD_FOLDER = os.path.join(APP_ROOT1, UPLOAD_PATH)

UPLOAD_PATH1 = 'static/predict'
UPLOAD_FOLDER1 = os.path.join(APP_ROOT1, UPLOAD_PATH1)

@main.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@main.route('/createdb/', methods=['GET', 'POST'])
def createdb():
    if not database_exists(URI):
        create_database(URI)
    print("資料庫已經存在")
    db.create_all()
    return redirect(url_for("main.index"))

@main.route('/dashboard_CT/')
def dashboard_CT():
    return render_template("dashboard_CT.html")

@main.route('/dashboard_MRI/')
def dashboard_MRI():
    return render_template("dashboard_MRI.html")

@main.route('/google_calendar/')
def google_calendar():
    return render_template("google_calendar.html")


@main.route('/about_us/')
def about_us():
    return render_template("about_us.html")






@main.route('/images_predict', methods=['GET', 'POST'])
def images_prefdict():

    all_image_files = []
    for filename in os.listdir(UPLOAD_FOLDER):
        ## 圖片檔

        #filename = filename[len(filename):]
        if (isImageFormat(filename)):
            all_image_files.append(filename)


    all_image_files2 = []
    for filename in os.listdir(UPLOAD_FOLDER1):
        ## 圖片檔

        #filename = filename[len(filename):]
        if (isImageFormat(filename)):
            all_image_files2.append(filename)

    return render_template('images_predict.html',**locals())



# 符合圖片檔案
def isImageFormat(link):
    if (link.find('.jpg') > -1 or link.find('.png') > -1 or link.find('.gif') > -1 or link.find('.jpeg') > -1):
        return True
    return False


@main.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        print(file)
        upload_path = '{}/{}'.format(UPLOAD_FOLDER, file.filename)
        file.save(upload_path)
        client.upload("/user/cloudera/test/uploads", upload_path)
        return 'ok'
